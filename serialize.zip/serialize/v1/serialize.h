
#ifndef _SERIALIZE_H_
#define _SERIALIZE_H_
//#include "rodan_mmrb.h"
#include <stdint.h>
#include <adi_processor.h>


typedef unsigned char	uint8; 
typedef signed char	sint8; 
typedef unsigned int	uint16;
typedef int		sint16;
typedef unsigned long	uint32;
typedef long		sint32;
#define SPI_MASTEREN
#define SPI_EN1
#define Continuous_Transfer
#define NULL_PTR 0x0   // a null pointer
#define DSPI 0x20000
#define BITM_SPI_CS_OVERRIDE_CTL1             (_ADI_MSK_3(0x00000002,0x00000002U, uint16_t  ))

#define DUMMY_BYTE      0x00
#define True  1
#define False 0

#define REG_(x)			(*(volatile uint32*)(x))
#define RD_R(REG_)		(REG_)
#define WR_R(REG_, D)	(REG_ = D)



#define FLUSHRWFIFO \
   WR_R(REG_(REG_SPI1_CTL), RD_R(REG_(REG_SPI1_CTL)) | BITM_SPI_CTL_TFLUSH  | BITM_SPI_CTL_RFLUSH); \
   while (RD_R(REG_(REG_SPI1_FIFO_STAT)) & (BITM_SPI_FIFO_STAT_TX| BITM_SPI_FIFO_STAT_RX)); \
   WR_R(REG_(REG_SPI1_CTL), (RD_R(REG_(REG_SPI1_CTL)) & ~BITM_SPI_CTL_TFLUSH) & ~BITM_SPI_CTL_RFLUSH); \
   //CHECK_BSY; // to solve or delete 
   
   
   
  
//#define CHECK_RX_FIFO \        
      //  (RD_R(REG_(REG_SPI1_FIFO_STAT)) & BITM_SPI_FIFO_STAT_RX); 

#define CHECK_TX_FIFO \
   while((RD_R(REG_(REG_SPI1_FIFO_STAT)) & BITM_SPI_FIFO_STAT_TX));
   
#define SET_CS \
   WR_R(REG_(REG_SPI1_CS_OVERRIDE), RD_R(REG_SPI1_CS_OVERRIDE) | BITM_SPI_CS_OVERRIDE_CTL1);
   
#define CLEAR_CS \
   WR_R(REG_(REG_SPI1_CS_OVERRIDE), RD_R(REG_(REG_SPI1_CS_OVERRIDE)) & BITM_SPI_CS_OVERRIDE_CTL);
   
#define ENABLE_RWOT \
   WR_R(REG_(REG_SPI1_CTL), RD_R(REG_(REG_SPI1_CTL)) | BITM_SPI_CTL_CON);
  
#define DISABLE_RWOT \
   WR_R(REG_(REG_SPI1_CTL), RD_R(REG_(REG_SPI1_CTL)) & ~BITM_SPI_CTL_CON);

   
   
   
   
  
   
 /* *********************************************************** */
   /* Return Type */
typedef enum 
{
	RetSpiError,       
	RetSpiSuccess    
}SPI_STATUS;

typedef unsigned char Bool;

/* Acceptable values for SPI master side configuration */
typedef enum _SpiConfigOptions
{
    OpsNull,  			// do nothing
    OpsWakeUp,			// enable transfer
    OpsInitTransfer,
    OpsEndTransfer,

}SpiConfigOptions;


/* char stream definition for */
typedef struct _structCharStream
{
    uint8* pChar;  /* buffer address that holds the streams */
    uint32 length; /* length of the stream in bytes */
}CharStream;

SPI_STATUS SpiCtlInit(void);
SPI_STATUS Serialize_SPI(
	const CharStream* char_stream_send, 
    CharStream* char_stream_recv, 
    SpiConfigOptions optBefore, 
	SpiConfigOptions optAfter);
   
   
   
   
   
   
   
#endif //end of file
   