/*
 **
 ** Source file generated on November 7, 2016 at 13:11:27.	
 **
 ** Copyright (C) 2016 Analog Devices Inc., All Rights Reserved.
 **
 ** This file is generated automatically based upon the options selected in 
 ** the Pin Multiplexing configuration editor. Changes to the Pin Multiplexing
 ** configuration should be made by changing the appropriate options rather
 ** than editing this file.
 **
 ** Selected Peripherals
 ** --------------------
 ** SPI2 (CLK, MOSI, MISO, CS_0)
 **
 ** GPIO (unavailable)
 ** ------------------
 ** P1_02, P1_03, P1_04, P1_05
 */

#include <stdint.h>
#include <adi_processor.h>

#define SPI1_CLK_PORTP1_MUX  ((uint16_t) ((uint16_t) 1<<12))
#define SPI1_MOSI_PORTP1_MUX  ((uint16_t) ((uint16_t) 1<<14))
#define SPI1_MISO_PORTP1_MUX  ((uint16_t) ((uint16_t) 1<<16))
#define SPI1_CS_0_PORTP1_MUX  ((uint16_t) ((uint16_t) 1<<18))

int32_t adi_initpinmux(void);

/*
 * Initialize the Port Control MUX Registers
 */
int32_t adi_initpinmux(void) {
    /* PORTx_MUX registers */
    *pREG_GPIO1_CFG = SPI1_CLK_PORTP1_MUX | SPI1_MOSI_PORTP1_MUX
     | SPI1_MISO_PORTP1_MUX | SPI1_CS_0_PORTP1_MUX;

    return 0;
}

