#include <common.h>
#include <adi_processor.h>
#include "SPI-NAND.h"
#include "Serialize.h"
#include <stdlib.h>  /* for 'NULL" definition */
#include <drivers/spi/adi_spi.h>
#include <drivers/pwr/adi_pwr.h>
#include <drivers/general/adi_drivers_general.h>
#include <rtos_map/adi_rtos_map.h>
#include "adi_spi_config.h"
#include <adi_cyclecount.h>
#include <adi_callback.h>
#include <drivers/pwr/adi_pwr.h>
#include <drivers/gpio/adi_gpio.h>



extern int32_t adi_initpinmux(void);


NMX_uint16 *uwpDeviceIdentification;
/* Buffers */
static uint8_t *txBuf[FlashPageSize];
static uint8_t *rxBuf[FlashPageSize];

int main(void)
{
 
   ReturnType     ERROR; 
   /* test system initialization */
    

    /* power init */
    adi_pwr_Init();
    common_Init();
   adi_initpinmux();
   
       if(ADI_PWR_SUCCESS != adi_pwr_SetClockDivider(ADI_CLOCK_HCLK,1))
    {
        DEBUG_MESSAGE("Failed to set clock divider for HCLK.");
        return FAILURE;
    }

    if(ADI_PWR_SUCCESS != adi_pwr_SetClockDivider(ADI_CLOCK_PCLK,1))
    {
        DEBUG_MESSAGE("Failed to set clock divider for PCLK.");
        return FAILURE;
    }

/* announce test */
    DEBUG_MESSAGE("Running SPI-NAND TEST...");

    /* test "loop" */
    while (1) {   
   
   ERROR= FlashBlockErase(0x0000u);
   DEBUG_RESULT("Flash_BlockEraseFailed",ERROR , Flash_BlockEraseFailed);
   ERROR = FlashReadDeviceIdentification(uwpDeviceIdentification);
   DEBUG_RESULT("Flash_Success", ERROR , Flash_Success);
   
   //read device identification
   FlashReadDeviceIdentification( uwpDeviceIdentification);
   
   printf("ID %d",*uwpDeviceIdentification);
   
    /* Fill TX buffer with random values 
    for (uint32_t i = 0u; i < FlashPageSize; i++) 
    {
        *txBuf[i] = rand() % 256u;
    } */
  /* ERROR= FlashBlockErase(0x0000u);
   DEBUG_RESULT("Flash_BlockEraseFailed",ERROR , Flash_BlockEraseFailed);
   FlashPageProgram( udAddr, *txBuf,  udNrOfElementsInArray)*/
    *txBuf = "SPI-NAND TEST 123456789";
    ERROR= FlashPageProgram(0x0000u,*txBuf,FlashPageSize);
    DEBUG_RESULT("Flash_Success", ERROR , Flash_Success);
    
    ERROR= FlashPageRead(0x0000u,*rxBuf);
    DEBUG_RESULT("Flash_Success", ERROR , Flash_Success);
    
    printf("sram:%s\n", *rxBuf);
    FlashReset();
  
    }}